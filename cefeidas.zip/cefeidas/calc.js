
function calcula(){
	let potenciaRefEl = document.querySelector('#potenciaRef');
	let distanciaRefEl = document.querySelector('#distanciaRef');
	let brilhoCalcEl = document.querySelector('#brilhoCalc');
	let constante;
	let distanciaCalc;
	brilho = potenciaRefEl.value/(4*3.14*distanciaRefEl.value*distanciaRefEl.value);
	constante= brilho*(distanciaRefEl.value*distanciaRefEl.value);
	distanciaCalc = Math.sqrt(constante*brilhoCalcEl.value)
	let respostaEl = document.querySelector('#resposta');
	respostaEl.innerHTML= `A distância é ${distanciaCalc}`;
}
let btnCalcular=document.querySelector('#calcular');
btnCalcular.addEventListener('click', calcula);